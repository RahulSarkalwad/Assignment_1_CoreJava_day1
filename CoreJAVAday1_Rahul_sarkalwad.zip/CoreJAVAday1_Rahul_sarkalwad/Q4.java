
public class Q4 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int number=5,factorial=1;
		for(int i=1;i<=number;i++)
		{
			factorial=factorial*i;
		}
		System.out.println("factorial of 5 is "+factorial);
	}
}
