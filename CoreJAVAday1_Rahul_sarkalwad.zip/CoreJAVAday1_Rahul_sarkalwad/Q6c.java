
public class Q6c {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,count=1000;
		for(i=101;i<count;i++)
			
			if(i%2==0)
			{
				
				System.out.print(i+" ");
			}
	}

}

