public class Q6b 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
        int i,count=100;
        		for(i=0;i<=count;i++)
        			
        			if(i%2!=0)
        			{
        				
        				System.out.print(i+" ");
        			}
	}

}

