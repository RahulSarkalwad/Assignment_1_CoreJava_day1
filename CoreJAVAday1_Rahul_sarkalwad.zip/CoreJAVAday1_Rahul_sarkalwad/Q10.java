import java.util.Scanner;

public class Q10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float tem; float tem_in_c;  
		Scanner sc = new Scanner(System.in);  
		System.out.print("Enter the tem you want to convert from ferranite to centrigade: ");  
		tem = sc.nextInt(); 
		tem_in_c=(float) ((float)(tem-32)/1.8);
		System.out.print("Tem in centrigade is "+tem_in_c);
		
	}

}
