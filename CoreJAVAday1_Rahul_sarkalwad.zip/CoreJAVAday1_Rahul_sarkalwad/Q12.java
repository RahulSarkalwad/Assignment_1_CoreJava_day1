
public class Q12 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Cube of a number from 1 to 10 is");
		for(int i=1;i<=10;i++)
			
			System.out.println((i*i*i));
			

	}

}
