
public class Q13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   float r=10,area;
   area=(float)3.14*r*r;
   System.out.print("area of a circle is "+area);
   
	}

}
