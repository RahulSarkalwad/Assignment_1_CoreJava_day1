import java.util.Scanner;
public class Q8 
{

	public static void main(String[] args) 
  {
		// TODO Auto-generated method stub
		int i,j,sum=1;
		for(i=0;i<8;i++)
		{
			for(j=0;j<=i;j++)
			{
				sum=i*j;
			System.out.print(i*j +" ");
			}
		
		System.out.println();
        }
   }

}
	

