public class Q15 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
int i,row=4,k;
for(i=0;i<=row;i++)
{
	if(i%2==0)
	{ 
		for(k=0;k<=(row-3);k++)
		{
	
		System.out.print("*");
		}
	    System.out.println("*");
	}
	else
	{
		for(k=0;k<=(row-3);k++)
	{
			System.out.print("#");
	
	}
		System.out.println("#");
}
	}

}
}
