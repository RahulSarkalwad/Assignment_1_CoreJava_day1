import java.util.Scanner;

public class Q16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the no. of elements which you want to add: ");
		int noofele=scanner.nextInt();
		int [] arr=new int[noofele];
		System.out.println("Enter numbers one by one ");
		for (int i=0;i<arr.length;i++)
		{
			arr[i]=scanner.nextInt();
		}
		for (int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		System.out.println("Sum of numbers is "+sum);
	}

}
