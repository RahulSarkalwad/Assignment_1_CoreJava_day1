
public class Q7c 
{ 
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int i,j = 0,count=20;
		for(i=0;i<=count;i++)
			
			if(i%2!=0)
			{
				
				System.out.print(i+" -");
				System.out.print((i+1)+" ");
				
			}
	}

}
