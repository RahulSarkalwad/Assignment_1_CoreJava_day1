
public class Q6d {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,count=100,sum=0;
		for(i=0;i<=count;i++)
			sum=sum+i;
	       {
	    	  System.out.print(sum+" ");
			}
	}

}
